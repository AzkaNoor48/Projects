import "../assets/css/App.css";
import GamesCard from "./Cards/GamesCard";
import arrowRight from "../assets/images/areas/arrowRight.png";
import arrow from "../assets/images/arrow.png";
import gen1 from "../assets/images/games/gen1.png";
import gen2 from "../assets/images/games/gen2.png";
import sesame1 from "../assets/images/games/sesame1.png";
import sesame2 from "../assets/images/games/sesame2.png";
import job1 from "../assets/images/games/job1.png";
import job2 from "../assets/images/games/job2.png";
import polka1 from "../assets/images/games/polka1.png";
import polka2 from "../assets/images/games/polka2.png";
import { motion } from "framer-motion";
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

const GAMES_DATA = [
  {
    figure1: gen1,
    title: "Genopets",
    figure2: gen2,
    name: "NFT Game ",
    color: "#184749;",
  },
  {
    figure1: polka1,
    title: " PolkaCity ",
    figure2: polka2,
    name: "NFT Game ",
    color: "#611B55;",
  },
];


const responsiveValue = {
  lg: {
    breakpoint: {
      max: Number.MAX_SAFE_INTEGER,
      min: 1201,
    },
    items: 4,
    slidesToSlide: 4,
  },
  md: {
    breakpoint: {
      max: 1200,
      min: 769,
    },
    items: 2,
    slidesToSlide: 2,
  },
  sm: {
    breakpoint: {
      max: 768,
      min: 0,
    },
    items: 1,
    slidesToSlide: 1,
  },
};


function Games({carouselResponsive = responsiveValue}) {
  return (
    <div className="growth-partner">
      <h2 className="areas-title">Our Most Recent Projects</h2>

      <div className="games-cards">
      <Carousel
        additionalTransfrom={0}
        arrows={false}
        autoPlay
        autoPlaySpeed={600000}
        customTransition="transform 800ms ease-out"
        transitionDuration={800}
        centerMode={false}
        className="eng-list"
        itemClass="eng-item"
        draggable
        focusOnSelect={false}
        infinite
        keyBoardControl
        minimumTouchDrag={80}
        renderButtonGroupOutside={false}
        renderDotsOutside={false}
        responsive={carouselResponsive}
        slidesToSlide={1}
        swipeable
        ssr
      >
        {GAMES_DATA.map((card, i) => (
          <GamesCard
            key={i}
            figure1={card.figure1}
            figure2={card.figure2}
            title={card.title}
            name={card.name}
          />
        ))}
        <div>
          <motion.div
            whileHover={{ backgroundColor: "#1D984B;" }}
            className="ses-card"
          >
            <div className="ses">
              <img className="ses-1" src={sesame1} alt="" />
              <img className="ses-2" src={sesame2} alt="" />
            </div>
            <div className="ses-title">Sesame Workshop</div>
            <div className="ses-lower">
              <div className="desc-ses">
                <h3><a  className="ses-read" href='https://tintash.com/portfolio/jobbox/'> Read more </a></h3>
                <h3 className="ses-name">App Development</h3>
              </div>{" "}
            </div>
          </motion.div>
        </div>
        <div>
          <motion.div
            whileHover={{ backgroundColor: "#0393DE" }}
            className="job-card"
          >
            <div className="job-g">
              <img className="job-1" src={job1} alt="" />
              <img className="job-2" src={job2} alt="" />
            </div>
            <div className="job-title">JobBox</div>
            <div className="desc-job">
              <h3><a  className="job-read" href='https://tintash.com/portfolio/sesame/'> Read more </a></h3>
              <h3 className="job-name">App Development</h3>
            </div>
          </motion.div>
        </div>
        </Carousel>

      </div>
      
      
      
      
      <div>
        <h2 ><a className="view" href='https://tintash.com/portfolio/'>view all &nbsp; &#x279E;</a> </h2>
      </div>
      <div>
        <motion.h2 whileHover={{ color: "#00AFAF" }} className="title-2">
          <a className="border">
            Lets take you to our services{" "}
            <img className="arrow-1" src={arrow} alt="" />
          </a>
        </motion.h2>
      </div>
    </div>
  );
}

export default Games;
