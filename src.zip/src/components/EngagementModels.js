import "../assets/css/App.css";
import EngagementCard from "../components/Cards/EngagementCard";
import arrow from "../assets/images/arrow.png";
import agile from "../assets/images/engagement/agile.png";
import discovery from "../assets/images/engagement/discovery.png";
import skill from "../assets/images/engagement/skill.png";
import {motion} from 'framer-motion';
import GrowthPartner from "./GrowthPartner";
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import lines from "../assets/images/clients/lines.png";



export const ENGAGEMENT_MODELS_DATA = {
  title: "Our Engagement Models",
  description:
    "Our extensive experience working with clients ranging from disruptive startups to Fortune 500 enterprises led us to develop different engagement models tailor-made to your needs.",
  cards: [
    {
      figure: discovery ,
      title: "Discovery Workshop",
      description:
        "Create Your Minimum Viable Product with our Dedicated Teams",
    

      benefits: [
        {
          label: "Idea validation",
        },
        {
          label: "Feasibility, Risk and Technical Evaluation / Assessment",
        },
        {
          label: "Cost and Time Estimation",
        },
        {
          label: "Trial Period for Team Fit",
          id: "benefits-tooltip-2",
          tooltip:
            "We believe in long term work relationships. But we always start with a small working experiment to see if we are the right fit for a new client. Hence, each engagement model has this trial experimental period.",
        },
      ],
      suitableFor: [
        "Individuals/startups at the inception of their product development journey",
        "Individuals/companies looking to validate their product idea and define the scope of their product.",
      ],
    },
    {
      figure:  agile ,
      title: "Agile Innovation Team",
      description: "Fixed Cost Discovery Leading to an Agile Team",
      

      benefits: [
        {
          label: "Fixed cost discovery",
        },
        {
          label: "Dedicated agile team",
        },
        {
          label: "Iterative sprint based development",
        },
        {
          label: "Trial period for team fit",
          id: "benefits-tooltip-1",
          tooltip:
            "We believe in long term work relationships. But we always start with a small working experiment to see if we are the right fit for a new client. Hence, each engagement model has this trial experimental period.",
        },
      ],
      suitableFor: [
        "Funded Startups",
        "Organizations looking for fast innovation teams",
      ],
    },
    {
      figure:  skill ,
      title: "Skill Based Augmentation",
      description:
        "Pick From a Wide Talent Pool to Build Teams With Specific Expertise",
      

      benefits: [
        {
          label: "Wide talent pool of expertise",
        },
        {
          label: "Easily scalable across projects",
        },
        {
          label: "Management control of team",
        },
        {
          label: "Trial period for team fit",
          id: "benefits-tooltip-3",
          tooltip:
            "We believe in long term work relationships. But we always start with a small working experiment to see if we are the right fit for a new client. Hence, each engagement model has this trial experimental period.",
        },
      ],
      suitableFor: [
        "For teams which need access to a particular expertise for their projects",
      ],
    },
  ],
};
const responsiveValue = {
  lg: {
    breakpoint: {
      max: Number.MAX_SAFE_INTEGER,
      min: 1201,
    },
    items: 3,
    slidesToSlide: 3,
  },
  md: {
    breakpoint: {
      max: 1200,
      min: 769,
    },
    items: 3,
    slidesToSlide: 3,
  },
  sm: {
    breakpoint: {
      max: 768,
      min: 426,
    },
    items: 3,
    slidesToSlide: 3,
  },
  xs: {
    breakpoint: {
      max: 425,
      min: 0,
    },
    items: 1,
    slidesToSlide: 1,
  },
};
  
function EngagementModels({carouselResponsive = responsiveValue}) {
  return (
    <div className="engagement">
      <div>
        <h2 className="head-title">
          Explore the offering most relevant to you.
        </h2>
      </div>

      <div className="eng-cards">

      <Carousel
        additionalTransfrom={0}
        arrows={false}
        autoPlay
        autoPlaySpeed={600000}
        customTransition="transform 800ms ease-out"
        transitionDuration={800}
        centerMode={false}
        className="eng-list"
        itemClass="eng-item"
        draggable
        focusOnSelect={false}
        infinite
        keyBoardControl
        minimumTouchDrag={80}
        renderButtonGroupOutside={false}
        renderDotsOutside={false}
        responsive={carouselResponsive}
        slidesToSlide={1}
        swipeable
        ssr
      >
        {ENGAGEMENT_MODELS_DATA.cards.map((card, i) => (
          <EngagementCard
            key={i}
            figure={card.figure}
            title={card.title}
            benefits={card.benefits}
            suitableFor={card.suitableFor}
            
          />
        ))}

</Carousel>
      </div>
      <div>
      <img className="lines" src={lines} alt="" />

      </div>
      <h4 className="title-mini-1">
        {" "}
        Not Sure? <span className="title-mini-2"> Get in touch</span>
      </h4>

      <div>
        <motion.h2  className="outer" whileHover={{ color: "#00AFAF" }} >
         <a  className="border" >  Our Journey so far <img className="arrow-1" src={arrow} alt="" /></a>  
        </motion.h2>
      </div>
    </div>
  );
}

export default EngagementModels;
