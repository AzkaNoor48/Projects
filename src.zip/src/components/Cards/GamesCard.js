import "../../assets/css/GamesCard.css";
import { motion } from "framer-motion";

function GamesCard({ figure1, figure2, title, name ,color}) {

  return (
    <div onMouseEnter={{color}} className="games-card">
      <img  className="figure-1" src={figure1} alt="" />
      <motion.img  animate={{overflowX:"hidden"}} className="figure-2" src={figure2} alt="" />
      <div className="card-title">{title}</div>
     <div className="lower">
     <div className="desc-g">
        <h3 className="g-read"> Read more</h3>
        <h3 className="name">{name}</h3>
      </div>
     </div>
    </div>
  )
}

export default GamesCard;
