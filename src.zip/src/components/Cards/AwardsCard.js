import "../../assets/css/AwardsCard.css";
import {motion} from 'framer-motion';

function AreasCard({ figure,title,link }) {
  return (
    <motion.div whileHover={{ background:'#011220',borderRadius: 20, y:-10}}  className="card-awards">
      <img className="figure-awards" src={figure} alt="" />

      <div className="awards-head"><a  className="awards-link" href={`${link}`} target="_blank">{title}</a></div>
    
    </motion.div>
  );
}

export default AreasCard;
