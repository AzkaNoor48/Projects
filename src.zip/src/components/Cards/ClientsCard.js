import "../../assets/css/ClientsCard.css";
import {motion} from 'framer-motion';

function ClientsCard({ figure,title,link }) {
  return (
    <motion.div whileHover={{ borderRadius: 20, y:-10}} className="card-clients">
      <img className="figure-clients" src={figure} alt="" />

      <div className="clients-head">{title}</div>
      <motion.h3   whileHover={{ color:'#00AFAF'}} ><a className="read" href={`${link}`} target="_blank">Read more</a></motion.h3>
 
    </motion.div>
  );
}

export default ClientsCard;
