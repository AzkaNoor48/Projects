import "../../assets/css/ResponseCard.css";
import { motion } from "framer-motion";
import commas from "../../assets/images/response/commas.png";


function ResponseCard({ figure, title, name, desc }) {
  return (
    <motion.div
      whileHover={{ borderRadius: 20, y: -10 }}
      className="card-response"
    >
      <img className="figure-response" src={figure} alt="" />
      <div className="response-detail">
      <img className="figure-commas" src={commas} alt="" />
        <div className="response-head">{title}</div>
        <h3 className="name-response">{name}</h3>
        <h3 className="desc-response">{desc}</h3>
      </div>
    </motion.div>
  );
}

export default ResponseCard;
