import "../../assets/css/AreasCard.css";
import {motion} from 'framer-motion';

function AreasCard({ figure,title, desc,link }) {
  return (
    <motion.div whileHover={{ background:'#011220',borderRadius: 20, y:-10}} className="card-services">
      <img className="figure-areas" src={figure} alt="" />

      <div className="card-head"><a  className="areas-link" href={`${link}`} target="_blank">{title}</a></div>
      <div className="descr">  {desc}    </div>
    </motion.div>
  );
}

export default AreasCard;
