import "../../assets/css/FooterCard.css";

function FooterCard({ title, desc }) {
  return (
    <div className="card-footer">
      <div className="footer-head">{title}</div>
      <div className="descr">
        {" "}
        <ul className="items-ul">
          {desc.map(({ label }, i) => (
            <li key={i} className="items">
              {label}
            </li>
          ))}
        </ul>{" "}
      </div>
    </div>
  );
}

export default FooterCard;
