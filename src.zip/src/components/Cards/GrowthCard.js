import "../../assets/css/GrowthCard.css";
import {motion} from 'framer-motion';

function GrowthCard({ figure,title, number }) {
  return (
    <motion.div whileHover={{ y:-50}} className="card-growth">
      <img className="figure" src={figure} alt="" />
      <div className="growth-title">{title}</div>
      <div className="number">{number}</div>
    </motion.div>
  );
}

export default GrowthCard;
