import "../../assets/css/EngagementCard.css";
import {motion} from 'framer-motion';

function EngagementModelCard({ title, benefits, suitableFor, figure }) {
  return (
    <motion.div whileHover={{ background:'#011220',borderRadius: 10, y:-10,paddingLeft:5}} className="card-eng">
      <img className="figure-eng" src={figure} alt="" />

      <div className="eng-title">{title}</div>
      <div className="card-sub-heading">Key Benefits</div>
      <div className="card-ul">
      <ul>
        {benefits.map(({ label }, i) => (
          <li key={i} className="card-li">
            {label}
          </li>
        ))}
      </ul>
      </div>
      <div className="card-sub-heading">Suitable For</div>
      <div className="card-ul">
      <ul >
        {suitableFor.map((label, i) => (
          <li  key={i} className="card-li">
            {label}
          </li>
        ))}
      </ul>
      <motion.h3   whileHover={{ color:'#00AFAF'}} className="more">Learn more</motion.h3>
      </div>
    </motion.div>
  );
}

export default EngagementModelCard;
