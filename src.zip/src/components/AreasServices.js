import "../assets/css/App.css";
import AreasCard from "./Cards/AreasCard";
import arrow from "../assets/images/arrow.png";
import arrowRight from "../assets/images/areas/arrowRight.png";
import software from "../assets/images/areas/software.png";
import blockchain from "../assets/images/areas/blockchain.png";
import product from "../assets/images/areas/product.png";
import quality from "../assets/images/areas/quality.png";
import {motion} from 'framer-motion';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import lines from "../assets/images/clients/lines.png";


const AREAS_SERVICES_DATA = [
  {
    figure: software,
    title: "Custom Software Development",
    desc: "Building on the experience of delivering 300+ successful products, we design, create, deploy and maintain custom software solutions to power digital products across various industries. With latest technology, interactive interface and engaging designs all products are custom developed whilst ensuring code quality and security. ",
    link: 'https://tintash.com/services/',
  },
  {

  figure: blockchain,
    title: " Blockchain Integration Web 3.0 ",
    desc: "We build blockchain solutions for digital evolution. With the successful delivery of a number of Blockchain projects, we have developed a range of expertise in Blockchain development and leverage the same product development proficiency that helped our startups, unicorns and fortune 500 clients to realize their dreams.    ",
    link: 'https://tintash.com/services/',
  },
  {
    figure: product,
    title: "Product Design   ",
    desc: "We combine product innovation with optimum usability. Through our iterative design process and thorough prototyping, we create an engaging and human-centric design that is scalable and a joy to use. Our team stays involved from the discovery phase to the final milestones to ensure that no part of your vision is lost in translation.    ",
    link: 'https://tintash.com/services/ui-ux',
  },
  {
    figure: quality,
    title: "Quality Assurance",
    desc: "We help ensure premium product quality by offering a comprehensive QA process which encompasses all stages of development. Our services consist of a combination of automated and manual testing, making sure your product follows up-to-date quality assurance standards.    ",
    link: 'https://tintash.com/services/quality-assurance',
  },
];
const responsiveValue = {
  lg: {
    breakpoint: {
      max: Number.MAX_SAFE_INTEGER,
      min: 1201,
    },
    items: 4,
    slidesToSlide: 4,
  },
  md: {
    breakpoint: {
      max: 1200,
      min: 769,
    },
    items: 3,
    slidesToSlide: 3,
  },
  sm: {
    breakpoint: {
      max: 768,
      min: 426,
    },
    items: 2,
    slidesToSlide: 2,
  },
  xs: {
    breakpoint: {
      max: 425,
      min: 0,
    },
    items: 1,
    slidesToSlide: 1,
  },
};

function AreasServices({carouselResponsive = responsiveValue}) {
  return (
    <div className="growth-partner">
      <h2 className="areas-title">Explore our Areas of Services</h2>
      <p className="growth-desc">
        {" "}
        We offer end-to-end product development solutions, tailor-made to fit
        your product's unique requirements.
      </p>
      <div className="areas-cards">
      <Carousel
        additionalTransfrom={0}
        arrows={false}
        autoPlay
        autoPlaySpeed={600000}
        customTransition="transform 800ms ease-out"
        transitionDuration={800}
        centerMode={false}
        className="eng-list"
        itemClass="areas-item"
        draggable
        focusOnSelect={false}
        infinite
        keyBoardControl
        minimumTouchDrag={80}
        renderButtonGroupOutside={false}
        renderDotsOutside={false}
        responsive={carouselResponsive}
        slidesToSlide={1}
        swipeable
        ssr
      >
        {AREAS_SERVICES_DATA.map((card, i) => (
          <AreasCard
            key={i}
            figure={card.figure}
            title={card.title}
            desc={card.desc}
            link={card.link}
          />
        ))}
        </Carousel>
      </div>
      <div>
      <img className="lines" src={lines} alt="" />

      </div>
      <div>
      <h2 ><a className="view" href='https://tintash.com/services/'>view all &nbsp; &#x279E;</a> </h2>
      </div>
      <div>
        <motion.h2 whileHover={{ color:'#00AFAF'}} className="title-2">
        <a  className="border">
          The projects we created for our amazing clients{" "}
          <img className="arrow-1" src={arrow} alt="" />
          </a>
        </motion.h2>
      </div>
    </div>
  );
}

export default AreasServices;
