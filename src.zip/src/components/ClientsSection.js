import "../assets/css/App.css";
import ClientsCard from "./Cards/ClientsCard";
import arrow from "../assets/images/arrow.png";
import camaradly from "../assets/images/clients/camaradly.png";
import polka from "../assets/images/clients/polka.png";
import stacks from "../assets/images/clients/stacks.png";
import lines from "../assets/images/clients/lines.png";
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import { motion } from "framer-motion";

const CLIENTS_DATA = [
  {
    figure: camaradly,
    title: "Camaradly was featured on Product Hunt and was at the #1 spot.",
    link: "https://www.producthunt.com/products/camaradly#camaradly",
  },
  {
    figure: polka,
    title: "Tintash Partners with PolkaCity to create a NFT Design ",
    link: "https://polkacity.medium.com/polkacity-nft-gaming-design-32c8c86deb19",
  },
  {
    figure: stacks,
    title: "The Stacks Blockchain API now  supports Rosetta Standard   ",
    link: "https://blog.blockstack.org/the-stacks-blockchain-api-now-supports-coinbases-rosetta-standard/",
  },
];

const responsiveValue = {
  lg: {
    breakpoint: {
      max: Number.MAX_SAFE_INTEGER,
      min: 1201,
    },
    items: 3,
    slidesToSlide: 3,
  },
  md: {
    breakpoint: {
      max: 1200,
      min: 769,
    },
    items: 2,
    slidesToSlide: 2,
  },
  sm: {
    breakpoint: {
      max: 768,
      min: 0,
    },
    items: 1,
    slidesToSlide: 1,
  },
};

function ClientsSection({carouselResponsive = responsiveValue}) {
  return (
    <div className="growth-partner">
      <h2 className="areas-title">Client Updates, News, and Wins </h2>

      <div className="clients-cards">
      <Carousel
        additionalTransfrom={0}
        arrows={false}
        autoPlay
        autoPlaySpeed={600000}
        customTransition="transform 800ms ease-out"
        transitionDuration={800}
        centerMode={false}
        className="eng-list"
        itemClass="eng-item"
        draggable
        focusOnSelect={false}
        infinite
        keyBoardControl
        minimumTouchDrag={80}
        renderButtonGroupOutside={false}
        renderDotsOutside={false}
        responsive={carouselResponsive}
        slidesToSlide={1}
        swipeable
        ssr
      >
        {CLIENTS_DATA.map((card, i) => (
          <ClientsCard
            key={i}
            figure={card.figure}
            title={card.title}
            link={card.link}
          />
        ))}
                </Carousel>

      </div>

      <img className="lines" src={lines} alt="" />

      <div>
        <motion.h2 whileHover={{ color: "#00AFAF" }} className="title-2">
          <a className="border">
            Have a look at what our clients have to say{" "}
            <img className="arrow-1" src={arrow} alt="" />
          </a>
        </motion.h2>
      </div>
    </div>
  );
}

export default ClientsSection;
