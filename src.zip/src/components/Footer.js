import "../assets/css/App.css";
import FooterCard from "./Cards/FooterCard";
import youtube from "../assets/images/footer/youtube.png";
import inst from "../assets/images/footer/inst.png";
import fb from "../assets/images/footer/fb.png";
import twitter from "../assets/images/footer/twitter.png";

const FOOTER_DATA = [

  {
    title: "Addresses    ",
    desc: [
      {
        label: "Raleigh, USA",
        link:""
      },
      {
        label: "California, USA",
        link:""
      },
      {
        label: " Toronto, Canada",
        link:""
      },
      {
        label: "Lahore, Pakistan",
        link:""
      },
      {
        label: "Islamabad, Pakistan",
        link:""
      },
    ],
  },
  {
    title: "Discover Tintash  ",

    desc: [
      {
        label: "About Us  ",
        link:"https://tintash.com/about/"
      },
      {
        label: "Privacy Policy",
        link:"https://tintash.com/privacy/"
      },
      {
        label: " Referrals Program",
        link:""
      },

    ],


  },
  {
    title: "Contact  ",
    desc: "    ",
    desc: [
      {
        label: "Contact Us  ",
        link:"https://tintash.com/contact/"
      },
      {
        label: "Careers    ",
        link:"https://tintash.com/careers/"
      },
   
      {
        label: "FAQ",
        link:"https://tintash.com/faq/"
      },
 
    ],
  },
];

function Footer() {
  return (
    <div>
    <div className="footer">
      <div className="footer-1">
        {FOOTER_DATA.map((card, i) => (
          <FooterCard key={i} title={card.title} desc={card.desc} />
        ))}
      </div>
      <div className="footer-2">
        <h3 className="social"> Social</h3>
        <div>
        <a href='https://www.youtube.com/user/TintashGame' className="icons"><img  src={youtube} alt="" /></a>
       <a href='https://instagram.com/tintash__?igshid=YmMyMTA2M2Y=' className="icons"> <img  src={inst} alt="" /></a>
       <a href='https://twitter.com/TintashApps' className="icons"> <img  src={twitter} alt="" /></a>
       <a href='https://web.facebook.com/Tintash?_rdc=1&_rdr' className="icons"> <img  src={fb} alt="" /></a>
</div>
      </div>
      
    </div>
    {/* <div className="footer-3">
        <h2 className="copy-right">Copyright 2022 Tintash - All Rights Reserved
        Privacy Policy </h2>
      </div> */}
      </div>
  );
}

export default Footer;
