import "../assets/css/App.css";
import ResponseCard from "./Cards/ResponseCard";
import arrow from "../assets/images/arrow.png";
import anum from "../assets/images/response/anum.png";
import amra from "../assets/images/response/amra.png";
import david from "../assets/images/response/david.png";
import paul from "../assets/images/response/paul.png";
import patrick from "../assets/images/response/patrick.png";
import lines from "../assets/images/clients/lines.png";
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

import { motion } from "framer-motion";

const RESPONSE_DATA = [
  {
    figure: anum,
    title:
      "Their experience in the field and the speed at which they work impressed us.",
    name: "Anum T. Hussain",
    desc: "CEO Fitness App",
  },
  {
    figure: paul,
    title:
      "[They] are realistic in what they can do, and don’t oversell themselves",
    name: "Paul Collins",
    desc: "Stick Sports",
  },
  {
    figure: david,
    title:
      "[T]hey manage their projects very well, and identify questions and gaps very quickly",
    name: "Dvid Cohen-Tanugi",
    desc: "Embr",
  },
  {
    figure: patrick,
    title:
      "    They [Tintash Labs] were flexible and adaptable to the problem and issues encountered, an very resourceful when dealing with issues.",
    name: "Patrick Cosgrove",
    desc: "Life Print",
  },
  {
    figure: amra,
    title:
      "    I am fond of the quality of their work and their willingness to be present as a team member.",
    name: "Amra Tareen",
    desc: "Bed Bath and Beyond",
  },
  
];
const responsiveValue = {
  lg: {
    breakpoint: {
      max: Number.MAX_SAFE_INTEGER,
      min: 1201,
    },
    items: 1,
    slidesToSlide: 1,
  },
  md: {
    breakpoint: {
      max: 1200,
      min: 769,
    },
    items: 1,
    slidesToSlide: 1,
  },
  sm: {
    breakpoint: {
      max: 768,
      min: 0,
    },
    items: 1,
    slidesToSlide: 1,
  },
};
function ClientsResponse({carouselResponsive = responsiveValue}) {
  
  return (
    <div className="growth-partner">
      <h2 className="areas-title">Client Updates, News, and Wins </h2>

      <div className="response-clients">
      <Carousel
        additionalTransfrom={0}
        arrows={true}
        autoPlay
        autoPlaySpeed={600000}
        customTransition="transform 800ms ease-out"
        transitionDuration={800}
        centerMode={false}
        className="connect__carousel-game-list"
        itemClass="connect__carousel-game-item"
        draggable
        focusOnSelect={false}
        infinite
        keyBoardControl
        minimumTouchDrag={80}
        renderButtonGroupOutside={false}
        renderDotsOutside={false}
        responsive={carouselResponsive}
        slidesToSlide={1}
        swipeable
        ssr
      >
        {RESPONSE_DATA.map((card, i) => (
          <ResponseCard key={i} figure={card.figure} title={card.title} name={card.name} desc={card.desc} />
        ))}

</Carousel>
      </div>
      
      <img className="lines" src={lines} alt="" />

      <div>
        <motion.h2 whileHover={{ color: "#00AFAF" }} className="title-2">
          <a  className="border">
          Have a look at what our clients have to say{" "}
          <img className="arrow-1" src={arrow} alt="" />
          </a>
        </motion.h2>
      </div>
    </div>
  );
}

export default ClientsResponse;
