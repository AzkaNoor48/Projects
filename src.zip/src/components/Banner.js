

import "../assets/css/App.css";
import Tintash  from "../assets/images/Tintash.png";

function Banner() {
    return (
<div className="landing">
      <div className="up">
        <div className="left-1">
          <img src={Tintash} alt=''/>
        </div>
        <ul className="menubar">
        <li ><a href='https://tintash.com/about/' className="menu"> About Us</a></li>
        <li ><a href='https://tintash.com/services/' className="menu"> Services</a></li>
        <li ><a href='https://tintash.com/verticals/' className="menu"> Verticals</a></li>
         <li ><a href='https://tintash.com/portfolio/' className="menu">Portfolio</a></li>
         <li ><a href='https://tintash.com/careers/' className="menu">Careers</a></li>
         <li ><a href='https://tintash.com/contact/' className="menu">Contact Us</a></li>
        </ul>
      </div>
      </div>
    );
}

export default Banner;
