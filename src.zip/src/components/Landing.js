import React, { useState } from 'react'
import "../assets/css/App.css";
import raven from "../assets/images/raven.png";
import bbc from "../assets/images/bbc.png";
import stacks from "../assets/images/stacks.png";
import beyond from "../assets/images/beyond.png";
import careem from "../assets/images/careem.png";
import bar from "../assets/images/bar.png";
import arrow from "../assets/images/arrow.png";
import down from "../assets/images/down.png";
import { motion } from "framer-motion";

function Landing() {


  return (
    <section className=" landing">
      <div className="bottom">
        <div className="left">
          <h2 className="heading">
            We are a mobile and web development company
          </h2>
          <p className="description">
            Tintash is a global, remote-first design and 
            development firm. We work closely with you to design
            and build your digital products. Our clients include
            several Startups, Unicorns and Fortune 500s.
          </p>
          <motion.h2 className="title" whileHover={{ color: "#00AFAF" }} >
          <a  className="border">
            Lets talk about your project{" "}
            <img
              className="arrow"
              src={arrow}
              alt=""
            />
          </a>

        </motion.h2>
        </div>
        <div className="right">
          <div className="head-1">
          We Design & Build<span className='head-2'> <br></br>  <img className='bar' src={bar} alt="bar" />{" "}Products</span>
          </div>

          <div className="desc">
            Trusted by startups and Fortune 500 Companies{" "}
          </div>
          <ul className="games">
            <li className="logos">
              {" "}
              <img src={stacks} alt="" />{" "}
            </li>
            <li className="logos">
              {" "}
              <img src={raven} alt="" />
            </li>
            <li className="logos">
              {" "}
              <img src={bbc} alt="" />
            </li>
            <li className="logos">
              {" "}
              <img src={careem} alt="" />
            </li>
            <li className="logos">
              {" "}
              <img src={beyond} alt="" />{" "}
            </li>
          </ul>
        </div>
      </div>
      <img className="down" src={down} alt="" />
    </section>
  );
}

export default Landing;
