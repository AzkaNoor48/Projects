import "../assets/css/App.css";
import GrowthCard from "./Cards/GrowthCard"
import arrow from "../assets/images/arrow.png";
import unicorns from "../assets/images/growth/unicorns.png";
import fortune from "../assets/images/growth/fortune.png";
import clients from "../assets/images/growth/clients.png";
import project from "../assets/images/growth/project.png";
import team from "../assets/images/growth/team.png";
import {motion} from 'framer-motion';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

  const GROWTH_CARDS_DATA = [
  {
    figure: project,
    title: "Projects Delivered",
    number: "300+",
  },
  {
    figure: team,
    title: "Strong Team    ",
    number: "150+",
  },
  {
    figure: clients,
    title: "Raised By Clients    ",
    number: "$750M",
  },
  {
    figure: unicorns,
    title: "Unicorns   ",
    number: "03",
  },
  {
    figure: fortune,
    title: "Fortune 500",
    number: "03",
  },
];

const responsiveValue = {
  xl: {
    breakpoint: {
      max: Number.MAX_SAFE_INTEGER,
      min: 2560,
    },
    items: 5,
    slidesToSlide: 5,
  },
  lg: {
    breakpoint: {
      max: 2559,
      min: 1441,
    },
    items: 4,
    slidesToSlide: 4,
  },
  md: {
    breakpoint: {
      max: 1400,
      min: 769,
    },
    items: 3,
    slidesToSlide: 3,
  },
  sm: {
    breakpoint: {
      max: 768,
      min: 426,
    },
    items: 2,
    slidesToSlide: 2,
  },
  sm: {
    breakpoint: {
      max: 425,
      min: 0,
    },
    items: 1,
    slidesToSlide: 1,
  },
};

function GrowthPartner({carouselResponsive = responsiveValue}) {
  return (
    <div className="growth-partner">
       <h2 className="head-title">
        We’re a Growth Partner to Industry leaders
      </h2>
      <p className="growth-desc">
        {" "}
        We believe in long-term relationships and work closely with you to
        supercharge you growth and success. Our partners represent some of the
        best companies in the world, from innovative startups to Fortune 500
        giants.
      </p>
      <div className="growth-cards">
      <Carousel
        additionalTransfrom={0}
        arrows={false}
        autoPlay
        autoPlaySpeed={600000}
        customTransition="transform 800ms ease-out"
        transitionDuration={800}
        centerMode={false}
        className="growth-list"
        itemClass="growth-item"
        draggable
        focusOnSelect={false}
        infinite
        keyBoardControl
        minimumTouchDrag={80}
        renderButtonGroupOutside={false}
        renderDotsOutside={false}
        responsive={carouselResponsive}
        slidesToSlide={1}
        swipeable
        ssr
      >
        {GROWTH_CARDS_DATA.map((card, i) => (
          <GrowthCard
            key={i}
            figure={card.figure}
            title={card.title}
            number={card.number}
          />
        ))}
                </Carousel>

      </div>
     <div>
        <motion.h2 whileHover={{ color:'#00AFAF'}} className="title-2">
        <a  className="border">
          The projects we created for our amazing clients{" "}
          <img className="arrow-1" src={arrow} alt="" />
          </a>
        </motion.h2>
      </div>
    </div>
  );
}

export default GrowthPartner;
