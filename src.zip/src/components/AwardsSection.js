import "../assets/css/App.css";
import AwardsCard from "./Cards/AwardsCard";
import arrow from "../assets/images/arrow.png";
import aws from "../assets/images/awards/aws.png";
import clutch from "../assets/images/awards/clutch.png";
import deliver from "../assets/images/awards/deliver.png";
import mobile from "../assets/images/awards/mobile.png";
import company from "../assets/images/awards/company.png";
import {motion} from 'framer-motion';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';

const AWARDS_DATA = [
  {
    figure: aws,
    title: "AWS Consulting Partner (2020)",
    link: '',
  },
  {
    figure: clutch,
    title: "Top 1000 Companies on Clutch (2020) ",
    link: 'https://clutch.co/profile/tintash',
  },
  {
    figure: deliver,
    title: "Clients Say We Deliver  On Clutch   ",
    link: 'https://clutch.co/profile/tintash',
  },
  {
    figure: mobile,
    title: "Top Mobile App Development Company",
    link: 'https://themanifest.com/app-development/companies',
  },
  {
    figure: company,
    title: "Top 1000 Companies on Clutch (2020)",
    link: 'https://clutch.co/profile/tintash',
  },
];

const responsiveValue = {
  lg: {
    breakpoint: {
      max: Number.MAX_SAFE_INTEGER,
      min: 1600,
    },
    items: 5,
    slidesToSlide: 5,
  },
  md: {
    breakpoint: {
      max: 1599,
      min: 769,
    },
    items: 3,
    slidesToSlide: 3,
  },
  sm: {
    breakpoint: {
      max: 768,
      min: 426,
    },
    items: 2,
    slidesToSlide: 2,
  },
  xs: {
    breakpoint: {
      max: 425,
      min: 0,
    },
    items: 1,
    slidesToSlide: 1,
  },
};

function AwardsSection({carouselResponsive = responsiveValue}) {
  return (
    <div className="growth-partner">
      <h2 className="areas-title">Awards & Recognitions </h2>
      <p className="awards-desc">
        {" "}
        We are proud to be recognized for our commitment and expertise within
        the industry. To us, these are more than trophies on a shelf, they
        represent our commitment to building the very best teams and solutions
        for our clients and their products.
      </p>
      <div className="awards-cards">
      <Carousel
        additionalTransfrom={0}
        arrows={false}
        autoPlay
        autoPlaySpeed={600000}
        customTransition="transform 800ms ease-out"
        transitionDuration={800}
        centerMode={false}
        className="eng-list"
        itemClass="award-item"
        draggable
        focusOnSelect={false}
        infinite
        keyBoardControl
        minimumTouchDrag={80}
        renderButtonGroupOutside={false}
        renderDotsOutside={false}
        responsive={carouselResponsive}
        slidesToSlide={1}
        swipeable
        ssr
      >
        {AWARDS_DATA.map((card, i) => (
          <AwardsCard key={i} figure={card.figure} title={card.title}  link={card.link} />
        ))}
                </Carousel>

      </div>
     
      <div>
        <motion.h2 whileHover={{ color:'#00AFAF'}} className="title-2">
        <a className="border">
        Our Client Updates, News, and Wins {" "}
          <img className="arrow-1" src={arrow} alt="" />
          </a>
        </motion.h2>
      </div>
    </div>
  );
}

export default AwardsSection;
