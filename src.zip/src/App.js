import Landing from "./components/Landing";
import Banner from "./components/Banner";
import EngagementModels from "./components/EngagementModels";
import GrowthPartner from "./components/GrowthPartner";
import AreasServices from "./components/AreasServices";
import Games from "./components/Games";
import AwardsSection from "./components/AwardsSection";
import ClientsSection from "./components/ClientsSection";
import ClientsResponse from "./components/ClientsResponse";
import Footer from "./components/Footer";


function App() {
  return (
    <>
      <Banner />
      <Landing />
      <EngagementModels />
      <GrowthPartner />
      <Games />
      <AreasServices />
      <AwardsSection />
      <ClientsSection />
      <ClientsResponse />
      <Footer />
    </>
  );
}

export default App;
